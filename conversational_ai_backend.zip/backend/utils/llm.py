import requests

def get_llm_response(user_message: str) -> str:
    # Replace this with actual call to Groq's LLM API
    return f"Echo: {user_message}"  # Dummy response for testing
