from fastapi import APIRouter, Request
from backend.schemas.chat import ChatRequest, ChatResponse
from backend.utils.llm import get_llm_response
from backend.utils.db import save_message

router = APIRouter()

@router.post("/chat", response_model=ChatResponse)
async def chat(request: ChatRequest):
    user_message = request.message
    conversation_id = request.conversation_id
    ai_response = get_llm_response(user_message)
    save_message(user_message, ai_response, conversation_id)
    return ChatResponse(message=ai_response, conversation_id=conversation_id)
