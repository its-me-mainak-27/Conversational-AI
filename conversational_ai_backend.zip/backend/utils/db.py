from datetime import datetime

def save_message(user_message, ai_response, conversation_id):
    print(f"[{datetime.now()}] Saved: {user_message} -> {ai_response} (session: {conversation_id})")
